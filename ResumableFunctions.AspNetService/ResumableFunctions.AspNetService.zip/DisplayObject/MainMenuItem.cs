﻿namespace ResumableFunctions.MvcUi.DisplayObject;

public record MainMenuItem(string DisplayName, string PartialViewUrl);