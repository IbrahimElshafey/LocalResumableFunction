﻿using ResumableFunctions.Handler.UiService.InOuts;

namespace ResumableFunctions.MvcUi.DisplayObject
{
    public record ServicesListModel(List<ServiceInfo> Services);
}