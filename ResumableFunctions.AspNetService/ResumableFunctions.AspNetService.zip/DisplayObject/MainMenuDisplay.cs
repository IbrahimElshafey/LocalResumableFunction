﻿namespace ResumableFunctions.MvcUi.DisplayObject
{
    public class MainMenuDisplay
    {
        public MainMenuItem[] Items { get; set; }
        public string BackLinkText { get; set; }
        public string BackLink { get; set; }
    }
}
